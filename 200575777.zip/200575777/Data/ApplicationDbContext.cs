﻿using _200575777.Models;
using Microsoft.EntityFrameworkCore;

namespace _200575777.Data
{
    public class ApplicationDbContext : DbContext
    {
        public IConfiguration Configuration { get; set; }
        public ApplicationDbContext(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(Configuration.GetConnectionString("DbConnectionString"));
        }
        public DbSet<Student> Students { get; set; }
    }
}
